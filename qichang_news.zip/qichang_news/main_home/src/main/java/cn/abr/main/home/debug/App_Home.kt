package cn.abr.main.home.debug

import cn.abr.common.base.BaseApp

/**
 * 版权：汽场(北京)信息科技有限公司 版权所有
 *
 *
 * 作者：时志邦
 *
 *
 * 创建日期：2019/7/8/008
 *
 *
 * 描述：
 */
class App_Home : BaseApp() {
    override fun init() {

    }
}
