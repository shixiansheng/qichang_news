package cn.abr.lib.status_layout

/**
 * 版权：汽场(北京)信息科技有限公司 版权所有
 *
 *
 * 作者：时志邦
 *
 *
 * 创建日期：2019/5/30/030
 *
 *
 * 描述：
 */
internal interface OnStatusRetryListener {
    fun onRetry();
}
