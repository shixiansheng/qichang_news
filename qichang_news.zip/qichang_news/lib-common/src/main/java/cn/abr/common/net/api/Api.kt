package cn.abr.inabr.net.api


/**
 * @author 时志邦
 * @Description: ${TODO}(用一句话描述该文件做什么)
 */

object Api {

     const val QCV_URL = "http://www.qichangv.com/"
}
