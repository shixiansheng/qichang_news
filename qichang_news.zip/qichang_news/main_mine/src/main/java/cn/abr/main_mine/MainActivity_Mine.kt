package cn.abr.main_mine

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity_Mine : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_mine_activity_main)
    }
}
